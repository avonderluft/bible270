# frozen_string_literal: true

ENV['RAILS_ENV'] = 'test'

# SKIP_COV runs the suite with no coverage machinery — quicker, and what CI's
# test matrix uses, since only the coverage job needs a report.
unless ENV['SKIP_COV']
  require 'simplecov'

  # Coveralls only where it can actually post. Locally there is no token, and its
  # formatter would replace the console summary with a failed upload.
  posting = ENV['CI'] || ENV.fetch('COVERALLS_REPO_TOKEN', nil)
  if posting
    require 'coveralls'
    SimpleCov.formatters = SimpleCov::Formatter::MultiFormatter.new(
      [SimpleCov::Formatter::HTMLFormatter, Coveralls::SimpleCov::Formatter]
    )
  else
    SimpleCov.formatter = SimpleCov::Formatter::HTMLFormatter
  end

  SimpleCov.start do
    # Count files even when no test loads them. Without this, coverage flatters
    # itself by ignoring everything untested.
    track_files '{app,lib}/**/*.rb'

    add_filter '/test/'
    add_filter '/gemfiles/'
    add_filter 'lib/bible270/version.rb'

    # The HTML report breaks down by group, which is what shows where the
    # untested code actually is.
    add_group 'Plan',        'lib/bible270/plan.rb'
    add_group 'Library',     'lib/bible270'
    add_group 'Generators',  'lib/generators'
    add_group 'Models',      'app/models'
    add_group 'Controllers', 'app/controllers'
    add_group 'Helpers',     'app/helpers'
    add_group 'Mailers',     'app/mailers'

    # A floor to ratchet up as the Rails-dependent code gets tests:
    #   COVERAGE_FLOOR=35 bundle exec rake test
    minimum_coverage ENV['COVERAGE_FLOOR'].to_i if ENV['COVERAGE_FLOOR']
  end
end

$LOAD_PATH.unshift File.expand_path('../lib', __dir__)
require 'minitest/autorun'
require 'bible270/plan'
